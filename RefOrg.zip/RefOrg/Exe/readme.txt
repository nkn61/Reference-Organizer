Readme
=============================

Reference and Diary Organizer software (RefOrg application)  
is to create individual "WiKi" inside PC.

Download application, unzip and run RefOrgV.exe
Initial file "reforg_sample.rfg" should be loaded.

Open Help section for details [F1]

What are main features of this software?

1) RTF-pages with edited cross-links for internal or external sources.
2) File associated, embedded or encoded pages categorized by sections.
3) Reminders and calendar base structures.
4) Glossary, Vocabulary and Reference collections.

It should be useful for everyone who wish to keep 
organized records, various notes and images with descriptions what 
is highly relevant in AI age with mass informational products. 

=================================
 Reference and Diary Organizer

